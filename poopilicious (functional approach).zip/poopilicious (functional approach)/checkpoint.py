import pygame
from sys import exit
from random import randint

# class Player(pygame.sprite.Sprite):
#     def __init__(self):
#         super().__init__()
#         self.image = pygame.image.load("playerA.png").convert_alpha()
#         self.rect = self.image.get_rect(topleft=(30, 200))
#         self.gravity = 0
#     def player_input(self):
#         keys = pygame.key.get_pressed()
#         if keys[pygame.K_SPACE] and self.rect.bottom >= 300:
#             self.gravity = -20
#
#     def apply_gravity(self):
#         self.gravity += 1
#         self.rect.y += self.gravity
#         if self.rect.bottom >= 300:
#             self.rect.bottom = 300
#
#     def update(self):
#         self.player_input()
#         self.apply_gravity()

def display_score():
    current_time = int(pygame.time.get_ticks() / 1000) - start_time
    score_surf = test_font.render(f'SCORE : {current_time}' , False, (64,64,64))
    score_rect = score_surf.get_rect(center = (400,50))
    screen.blit(score_surf ,score_rect)
    return current_time

def obstacle_movement(obstacle_list):
    if obstacle_list :
        for obstacle_rect in obstacle_list:
            obstacle_rect.x -= 5

            if obstacle_rect.bottom == 300: screen.blit(poop_surf, obstacle_rect)
            else: screen.blit(flypoo_surf,obstacle_rect)
        obstacle_list = [obstacle for obstacle in obstacle_list if obstacle.x > -100 ]

        return obstacle_list
    else : return []

def collisions(player,obstacles):
    if obstacles:
        for obstacle_rect in obstacles:
            if player.colliderect(obstacle_rect): return False
    return True

def player_animation():
    global player_surf, player_index
    if player_rect.bottom < 325:
        player_surf = player_jump
    else:
        player_index += 0.1
        if player_index >= len(player_walk): player_index = 0
        player_surf = player_walk[int(player_index)]

pygame.init() 
screen = pygame.display.set_mode((800,400))
pygame.display.set_caption('Poopilicious')
clock = pygame.time.Clock()
game_active = False
start_time = 0
score = 0

test_font = pygame.font.Font('../poopfont4a.ttf', 30)
score_font = pygame.font.Font('../poopfont2.ttf', 30)

background_surface = pygame.image.load('../bg3.png').convert()

text_surf = test_font.render('POOPilicious', False,'white').convert()
text_rect = text_surf.get_rect(topleft= (0,0))


# score_surf = score_font.render('SCORE : ', False, (64,64,64))
# score_rect = score_surf.get_rect(center = (550, 375))

player_surface1 = pygame.image.load('playerA.png').convert_alpha()
player_surface2 = pygame.image.load('playerB.png').convert_alpha()
player_walk = [player_surface1, player_surface2]
player_index = 0
player_jump = pygame.image.load('playerC.png').convert_alpha()

player_surf = player_walk[player_index]
player_rect = player_surf.get_rect(topleft=(30, 200))
player_gravity = 0

#intro screen
player_stand = pygame.image.load('../used but useless now/poo.png').convert_alpha()
player_stand = pygame.transform.scale2x(player_stand )
player_stand_rect = player_stand.get_rect(center = (400,200))

 #intro screen text
game_name = test_font.render('POOPilicious', False ,(111,196,169))
game_name_rect = game_name.get_rect(center = (400,80))

game_message = test_font.render('press space to run' ,False ,(111,196,169))
game_message_rect = game_message.get_rect(center = (400,320))

poop_surf = pygame.image.load('../used but useless now/poo.png').convert_alpha()
poop_rect = poop_surf.get_rect(topleft = (600, 265))

#poop
poop_move1 = pygame.image.load('../poop ani/dung/dung1.png').convert_alpha()
poop_move2 = pygame.image.load('../poop ani/dung/dung3.png').convert_alpha()
poop_frames = [poop_move1,poop_move2]
poop_frame_index = 0
poop_surf = poop_frames[poop_frame_index]

# flypoo
flypoo1 = pygame.image.load('../poop ani/flypoop/flypoo1.png').convert_alpha()
flypoo2 = pygame.image.load('../poop ani/flypoop/flypoo2.png').convert_alpha()
flypoo3 = pygame.image.load('../poop ani/flypoop/flypoo3.png').convert_alpha()
flypoo_frames = [flypoo1, flypoo2]
fly_frame_index = 0
flypoo_surf = flypoo_frames[fly_frame_index]

obstacle_rect_list = []

#timer
obstacle_timer = pygame.USEREVENT + 1
pygame.time.set_timer(obstacle_timer,1500)

poop_animation_timer = pygame.USEREVENT + 2
pygame.time.set_timer(poop_animation_timer,500)

flypoo_animation_timer = pygame.USEREVENT + 3
pygame.time.set_timer(flypoo_animation_timer,200)


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if game_active:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and player_rect.bottom >= 325:
                    player_gravity = -20

            if event.type == pygame.MOUSEBUTTONDOWN and player_rect.bottom >= 325:
                if player_rect.collidepoint(event.pos):
                    player_gravity = -20
        else:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                game_active = True
                poop_rect.left = 800
                start_time = int(pygame.time.get_ticks() / 1000)

        if game_active:
            if event.type == obstacle_timer and game_active:
                if randint(0,2):
                    obstacle_rect_list.append(poop_surf.get_rect(bottomright = (randint(900,1100), 322)))
                else:
                    obstacle_rect_list.append(flypoo_surf.get_rect(bottomright=(randint(900, 1100), 200)))
            if event.type == poop_animation_timer:
                if poop_frame_index == 0 : poop_frame_index = 1
                else : poop_frame_index = 0
                poop_surf = poop_frames[poop_frame_index]
            if event.type == flypoo_animation_timer:
                if fly_frame_index == 0 : fly_frame_index = 1
                else : fly_frame_index = 0
                flypoo_surf = flypoo_frames[fly_frame_index]



    if game_active:
        screen.blit(background_surface, (0, 0))
        # pygame.draw.rect(screen, '#5EC353' , score_rect)
        # pygame.draw.rect(screen, '#5EC353', score_rect, 20)
        # screen.blit(score_surf, score_rect)
        score  = display_score()

        pygame.draw.rect(screen, '#7a5901', text_rect)
        screen.blit(text_surf, (0,0))

        # screen.blit(poop_surf, poop_rect)
        # poop_rect.x -= 4
        # if poop_rect.right <=0 : poop_rect.left = 800

        #player
        player_gravity += 1
        player_rect.y += player_gravity
        if player_rect.bottom >= 325: player_rect.bottom = 325
        player_animation()
        screen.blit(player_surf, player_rect)

        #Obstacle movement
        obstacle_rect_list = obstacle_movement(obstacle_rect_list)

        #collisions
        game_active = collisions(player_rect,obstacle_rect_list)
        #game over state
        if poop_rect.colliderect(player_rect):
            game_active = False
    else:
        screen.fill((94,129,162))
        screen.blit(player_stand, player_stand_rect)
        obstacle_rect_list.clear()
        player_rect.bottom = 325
        player_gravity = 0
        score_message = test_font.render(f'Your score : {score}', False , (111,196,169))
        score_message_rect = score_message.get_rect(center = (400,300))
        screen.blit(game_name,game_name_rect)

        if score == 0:
            screen.blit(game_message,game_message_rect)
        else :
            screen.blit(score_message,score_message_rect)

    pygame.display.update() 
    clock.tick(60)





